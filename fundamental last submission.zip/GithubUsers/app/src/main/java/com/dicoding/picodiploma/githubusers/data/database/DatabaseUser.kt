package com.dicoding.picodiploma.githubusers.data.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.dicoding.picodiploma.githubusers.data.entitas.EntitasLikedUser

@Database(entities = [EntitasLikedUser::class], version = 1, exportSchema = false)
abstract class DatabaseUser : RoomDatabase(){
    abstract fun dao(): DAO

    companion object {
        @Volatile
        private var instance: DatabaseUser? = null

        @JvmStatic
        fun databaseGet(context: Context): DatabaseUser {
            if (instance == null) {
                synchronized(DatabaseUser::class.java) {
                    instance = Room.databaseBuilder(context.applicationContext,
                    DatabaseUser::class.java, "Users.db").build()
                }
            }
            return instance as DatabaseUser
        }
    }
}