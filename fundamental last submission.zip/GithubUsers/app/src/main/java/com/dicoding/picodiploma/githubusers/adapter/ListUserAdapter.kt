package com.dicoding.picodiploma.githubusers.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.dicoding.picodiploma.githubusers.data.entitas.EntitasLikedUser
import com.dicoding.picodiploma.githubusers.databinding.ItemRowUserBinding

class ListUserAdapter : RecyclerView.Adapter<ListUserAdapter.ListViewHolder>(){
    private var onItemClickCallback: OnItemClickCallback? = null
    private var mData = ArrayList<EntitasLikedUser>()

    fun dataSet(items: List<EntitasLikedUser>) {
        mData.clear()
        mData.addAll(items)
        notifyDataSetChanged()
    }

    fun setOnItemClickCallback(onItemClickCallback: OnItemClickCallback) {
        this.onItemClickCallback = onItemClickCallback
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ListViewHolder {
        val binding = ItemRowUserBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ListViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ListViewHolder, position: Int) {
        holder.bind(mData[position])
    }

    override fun getItemCount(): Int = mData.size

    inner class ListViewHolder(private val binding: ItemRowUserBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(entitasLikedUser: EntitasLikedUser) {
            with(binding) {
                Glide.with(itemView.context)
                    .load(entitasLikedUser.avatarUrl)
                    .into(imgItemPhoto)
                tvItemName.text = entitasLikedUser.login
                itemView.setOnClickListener {
                    onItemClickCallback?.onItemClicked(entitasLikedUser) }
            }
        }
    }

    interface OnItemClickCallback {
        fun onItemClicked(data: EntitasLikedUser)
    }
}



