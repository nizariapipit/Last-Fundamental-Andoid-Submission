package com.dicoding.picodiploma.githubusers.adapter

import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.viewpager2.adapter.FragmentStateAdapter
import com.dicoding.picodiploma.githubusers.FollowerFragment
import com.dicoding.picodiploma.githubusers.FollowingFragment

class PageSectionAdapter(activity: AppCompatActivity) : FragmentStateAdapter(activity) {
    var username: String? = null

    override fun createFragment(position: Int): Fragment {
        var frag : Fragment? = null
        when (position) {
            0 -> frag = FollowerFragment.newInstace(username)
            1 -> frag = FollowingFragment.newInstance(username)
        }
        return frag as Fragment
    }

    override fun getItemCount(): Int {
        return 2
    }
}