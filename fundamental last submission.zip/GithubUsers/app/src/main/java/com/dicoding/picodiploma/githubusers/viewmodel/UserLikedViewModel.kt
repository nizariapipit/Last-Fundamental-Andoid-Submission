package com.dicoding.picodiploma.githubusers.viewmodel

import android.app.Application
import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import com.dicoding.picodiploma.githubusers.data.entitas.EntitasLikedUser
import com.dicoding.picodiploma.githubusers.repository.UserLikedRepository

class UserLikedViewModel(application: Application) : ViewModel() {

    val userLikedRepository: UserLikedRepository = UserLikedRepository(application)

    fun allLikedUserGet(): LiveData<List<EntitasLikedUser>> = userLikedRepository.userLikedGet()

    fun userInsert(entitasLikedUser: EntitasLikedUser) {
        userLikedRepository.insert(entitasLikedUser)
    }

    fun likedDelete(id: Int) {
        userLikedRepository.likedDelete(id)
    }
}