package com.dicoding.picodiploma.githubusers.viewmodel

import android.app.Application
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import java.lang.IllegalArgumentException

class ViewModelFactory (private var application: Application) : ViewModelProvider.NewInstanceFactory() {
    companion object {
        @Volatile
        private var instance: ViewModelFactory? = null

        @JvmStatic
        fun newInstacne(app: Application): ViewModelFactory {
            if(instance == null) {
                synchronized(ViewModelFactory::class.java) {
                    instance = ViewModelFactory(app)
                }
            }
            return instance as ViewModelFactory
        }
    }

    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(UserLikedViewModel::class.java)) {
            return UserLikedViewModel(application) as T
        }
        throw IllegalArgumentException("Unknown viewModel class: ${modelClass.name}")
    }
}