package com.dicoding.picodiploma.githubusers

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import com.dicoding.picodiploma.githubusers.adapter.ListUserAdapter
import com.dicoding.picodiploma.githubusers.data.entitas.EntitasLikedUser
import com.dicoding.picodiploma.githubusers.databinding.ActivityUserFaveBinding
import com.dicoding.picodiploma.githubusers.viewmodel.UserLikedViewModel
import com.dicoding.picodiploma.githubusers.viewmodel.ViewModelFactory

class UserFaveActivity : AppCompatActivity() {
    private lateinit var binding: ActivityUserFaveBinding
    private lateinit var itemRowUserAdapter: ListUserAdapter
    private lateinit var userLikedGet: UserLikedViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_user_fave)
        binding = ActivityUserFaveBinding.inflate(layoutInflater)
        setContentView(binding.root)
        supportActionBar?.title = "Your Favorites"

        showLoading(true)

        val layoutManager = LinearLayoutManager(this)
        binding.userLikedList.layoutManager = layoutManager
        val itemDecoration = DividerItemDecoration(this, layoutManager.orientation)
        binding.userLikedList.addItemDecoration(itemDecoration)
        showUserLikedAdapter()
        userLikedGet = obtainUserLikedViewModel(this@UserFaveActivity)
        userLikedGet.allLikedUserGet().observe(this, {likedList ->
            if (likedList != null) {
                itemRowUserAdapter.dataSet(likedList)
                showLoading(false)
            }
        })

    }

    private fun obtainUserLikedViewModel(activity: AppCompatActivity):UserLikedViewModel {
        val factory = ViewModelFactory.newInstacne(activity.application)
        return ViewModelProvider(activity, factory).get(UserLikedViewModel::class.java)
    }

    private fun showUserLikedAdapter() {
        binding.userLikedList.layoutManager = LinearLayoutManager(this)
        itemRowUserAdapter = ListUserAdapter()
        itemRowUserAdapter.notifyDataSetChanged()
        binding.userLikedList.adapter = itemRowUserAdapter
        itemRowUserAdapter.setOnItemClickCallback(object : ListUserAdapter.OnItemClickCallback {
            override fun onItemClicked(data: EntitasLikedUser) {
                detailforlUser(data)
            }
        })
    }

    private fun detailforlUser(data: EntitasLikedUser){
        val detailUser = Intent(this@UserFaveActivity, MoreActivity::class.java)
        detailUser.putExtra(MoreActivity.DETAIL_USER, data)
        startActivity(detailUser)
    }

    private fun showLoading(state: Boolean) { binding.progressBar.visibility = if (state) View.VISIBLE else View.GONE }
}