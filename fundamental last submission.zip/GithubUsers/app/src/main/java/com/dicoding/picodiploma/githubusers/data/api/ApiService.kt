package com.dicoding.picodiploma.githubusers.data.api

import retrofit2.Call
import retrofit2.http.*

interface ApiService {
    @Headers("Authorization: token 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")
    @GET("search/users")
    fun searchQueryGet(
        @Query("q") login: String
    ): Call<ResponseUsers>

    @GET("users/{login}/following")
    fun usersFollowingGet(
        @Path("login") login: String?
    ): Call<List<UserDataObject>>

    @GET("users/{login}/followers")
    fun usersFollowerGet(
        @Path("login") login: String?
    ): Call<List<UserDataObject>>
}
