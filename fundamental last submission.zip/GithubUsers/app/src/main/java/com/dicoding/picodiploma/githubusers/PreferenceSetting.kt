package com.dicoding.picodiploma.githubusers

import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class  PreferenceSetting private constructor(private val dataStore: DataStore<Preferences>){
    private val THEME_KEY = booleanPreferencesKey("theme_setting")

    fun themeSettingGet(): Flow<Boolean> {
        return dataStore.data.map { preferences ->
            preferences[THEME_KEY] ?: false
        }
    }

    suspend fun themeSettingSave(isDarkModeActive: Boolean) {
        dataStore.edit { preferences ->
            preferences[THEME_KEY] = isDarkModeActive
        }
    }

    companion object {
        @Volatile
        private var INSTANCE: PreferenceSetting? = null

        fun newInstance(dataStore: DataStore<Preferences>): PreferenceSetting {
            return INSTANCE ?: synchronized(this) {
                val instance = PreferenceSetting(dataStore)
                INSTANCE = instance
                instance
            }
        }
    }
}